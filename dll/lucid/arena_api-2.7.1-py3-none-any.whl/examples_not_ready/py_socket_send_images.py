# -----------------------------------------------------------------------------
# Copyright (c) 2023, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

import time

from arena_api.enums import PixelFormat
from arena_api.system import system
from arena_api.socket import Socket

'''
Sender: Introduction
    This example introduces a script or program designed to send data using 
    the User Datagram Protocol (UDP), which is one of the core members of
    the Internet Protocol Suite.

NOTE: Before starting this example, please enable the "SOCKET IMAGES" option 
	on the AVMP Advanced Options page.
'''

'''
=-=-=-=-=-=-=-=-=-
=-=- SETTINGS =-=-
=-=-=-=-=-=-=-=-=-
'''
TAB1 = "  "
pixel_format = PixelFormat.BGR8


def create_device_with_tries():
	'''
	Waits for the user to connect a device before raising
		an exception if it fails
	'''
	tries = 0
	tries_max = 6
	sleep_time_secs = 10
	devices = None
	while tries < tries_max:
		devices = system.create_device()
		if not devices:
			print(
				f'{TAB1}Try {tries+1} of {tries_max}: waiting for {sleep_time_secs} '
				f'secs for a device to be connected!')
			for sec_count in range(sleep_time_secs):
				time.sleep(1)
				print(f'{TAB1}{sec_count + 1 } seconds passed ',
					'.' * sec_count, end='\r')
			tries += 1
		else:
			return devices
	else:
		raise Exception(f'{TAB1}No device found! Please connect a device and run '
						f'the example again.')


def example_entry_point():
	devices = create_device_with_tries()

	device = system.select_device(devices)

	'''
	Setup stream values
	'''
	tl_stream_nodemap = device.tl_stream_nodemap
	tl_stream_nodemap['StreamAutoNegotiatePacketSize'].value = True
	tl_stream_nodemap['StreamPacketResendEnable'].value = True

	device.start_stream()
	number_of_buffers = 5
	buffers = device.get_buffer(number_of_buffers)
	
	# Send socket
	socket = Socket()
	socket.open_sender()
	socket.add_destination(54000)

	try:
		count = 1
		for buffer in buffers:
			socket.send_singleImage(buffer)
			print(f'{TAB1}buffer{count : 02} sent successfully!')
			count += 1
			time.sleep(4)
			
	except KeyboardInterrupt:
		print(f'{TAB1}Keyboard Interrupt: Stopping the stream')

	# Clean up
	device.requeue_buffer(buffers)
	device.stop_stream()
	socket.close_sender()

	# Destroy Device
	system.destroy_device()
	print(f'{TAB1}Destroyed all created devices')


if __name__ == "__main__":
	print("Example Started\n")
	example_entry_point()
	print("\nExample Completed")

