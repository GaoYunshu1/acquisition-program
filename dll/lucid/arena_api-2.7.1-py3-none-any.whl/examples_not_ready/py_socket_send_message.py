# -----------------------------------------------------------------------------
# Copyright (c) 2023, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

import time
from datetime import datetime

from arena_api.enums import PixelFormat
from arena_api.__future__.save import Writer
from arena_api.system import system
from arena_api.buffer import BufferFactory
from arena_api.socket import Socket

'''
Sender: Introduction
    This example introduces a script or program designed to send data using 
    the User Datagram Protocol (UDP), which is one of the core members of
    the Internet Protocol Suite..
'''

'''
=-=-=-=-=-=-=-=-=-
=-=- SETTINGS =-=-
=-=-=-=-=-=-=-=-=-
'''

def example_entry_point():
	# Send socket
	socket = Socket()
	socket.open_sender()
	socket.add_destination(12345)

	
	message = 'option list'
	socket.send_message(message)
	print( "message : \"" + message + "\" , sent successfully!\n")

	socket.close_sender()

if __name__ == "__main__":
	print("Example Started\n")
	example_entry_point()
	print("\nExample Completed")

