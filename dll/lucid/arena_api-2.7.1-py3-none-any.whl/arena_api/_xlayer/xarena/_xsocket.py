# -----------------------------------------------------------------------------
# Copyright (c) 2023, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

import ctypes
from ctypes import byref

from arena_api._xlayer.xarena.arenac import harenac
from arena_api._xlayer.xarena.arenac_types import (
    acSocket, acBuffer, size_t, char_ptr)


class _xSocket:

    def __init__(self):
        self.hxsocket = acSocket(None)
        self.xSocketCreat()

    def xSocketCreat(self):
       
       # AC_ERROR acSocketCreate(
       #   acSocket* phSocket)
       harenac.acSocketCreate(byref(self.hxsocket))

    def xSocketDestroy(self):
       
       # AC_ERROR acSocketDestroy(
       #   acSocket hSocket)
       harenac.acSocketDestroy(self.hxsocket)

    def xSocketOpenSender(self):
         
         # AC_ERROR acSocketOpenSender(
         #   acSocket hSocket)
         harenac.acSocketOpenSender(self.hxsocket)

    def xSocketCloseSender(self):

        # AC_ERROR acSocketCloseSender(
        #   acSocket hSocket)
        harenac.acSocketCloseSender(self.hxsocket)

    def xSocketAddDestination(self, port):

        # AC_ERROR acSocketAddDestination(
        #   acSocket hSocket,
        #   unsigned short port)
        harenac.acSocketAddDestination(self.hxsocket, ctypes.c_ushort(port))

    def xSocketSendMessage(self, message):

        message_p = char_ptr(message.encode())
        # AC_ERROR acSocketSendMessage(
        #   acSocket hSocket,
        #   const char* pMessage)
        harenac.acSocketSendMessage(self.hxsocket, message_p)

    def xSocketSendImage(self, buffer_p):
        
        h_buffer = acBuffer(buffer_p)
        # AC_ERROR acSocketSendImage(
        #   acSocket hSocket,
        #   acBuffer hBuffer)
        harenac.acSocketSendImage(self.hxsocket, h_buffer)

    def xSocketOpenListener(self, port):

        # AC_ERROR acSocketOpenListener(
        #   acSocket hSocket,
        #   unsigned short port)
        harenac.acSocketOpenListener(self.hxsocket, ctypes.c_ushort(port))

    def xSocketCloseListener(self):

        # AC_ERROR acSocketCloseListener(
        #   acSocket hSocket)
        harenac.acSocketCloseListener(self.hxsocket)
    
    def xSocektReceiveMessage(self):

        BUFFER_SIZE = 4096
        buffer_p = ctypes.create_string_buffer(BUFFER_SIZE)
        buf_len = size_t(BUFFER_SIZE)

        # AC_ERROR acSocketReceiveMessage(
        #   acSocket hSocket,
        #   char* pMessageBuf,
        #   size_t* pBufLen)
        harenac.acSocketReceiveMessage(self.hxsocket, buffer_p, byref(buf_len))
        return (buffer_p.value).decode()

    def xSocketReceiveImage(self):
            
            # AC_ERROR acSocketReceiveSingleImage(
            #   acSocket hSocket,
            #   acBuffer* phBuffer)
            hxbuffer = acBuffer(None)
            harenac.acSocketReceiveImage(self.hxsocket, byref(hxbuffer))
            return hxbuffer.value

        
   






  