# -----------------------------------------------------------------------------
# Copyright (c) 2024, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

from ctypes import POINTER, byref, cast

from arena_api._xlayer.xsave.savec import hsavec
from arena_api._xlayer.xsave.savec_types import (char_ptr, saveReader, size_t,
                                                 uint8_t, uint64_t, wchar_ptr,
                                                 bool8_t)
from arena_api._xlayer.xsave.xsave_defaults import XSAVE_STR_BUF_SIZE_DEFAULT

from arena_api._xlayer.info import Info
_info = Info()


class xReader:
    '''
    direct mapping for c functions exclude __init__ and __del__

    '''

    def __init__(self, file_name, top_to_bottom=True):
        self.reader = None
        self.hReader = None

        if (not top_to_bottom):  # top to bottom is false (create bottom to top)
            if not _info.is_windows:
                self.reader = self._CreateBottomToTop(file_name)
            else:
                self.reader = self._CreateBottomToTopU(file_name)

        elif (file_name):
            if not _info.is_windows:
                self.reader = self._Create(file_name)
            else:
                self.reader = self._CreateU(file_name)

        else:
            raise ValueError('xInternal : not all args have been passed')
        
        self.hReader = saveReader(self.reader)

        # redirect functions on windows to use the Unicode SaveC function
        # WINDOWS ONLY: UNICODE handling
        # in __init__ function this function will be assigned to
        # self.SetExtension so the upper levels have on function to call
        # and the unicode for windows is handled in the __init__
        if _info.is_windows:
            self.LoadRawData = self.LoadRawDataU

    def __del__(self):
        if self.hReader:
            return self._Destroy()

    # only call from __init__
    @staticmethod
    def _Create(file_name):

        file_name_p = char_ptr(file_name.encode())
        hReader = saveReader(None)

        # SC_ERROR saveReaderCreate(
        #   saveReader* phReader,
        #   const char* pFileName)
        hsavec.saveReaderCreate(
            byref(hReader),
            file_name_p)

        return hReader.value
    
    # only call from __init__
    @staticmethod
    def _CreateU(file_name):

        file_name_p = wchar_ptr(file_name)
        hReader = saveReader(None)

        # SC_ERROR saveReaderCreateU(
        #   saveReader* phReader,
        #   const wchar_t* pFileName)
        hsavec.saveReaderCreateU(
            byref(hReader),
            file_name_p)

        return hReader.value
    
    # only call from __init__
    @staticmethod
    def _CreateBottomToTop(file_name):

        file_name_p = char_ptr(file_name.encode())
        hReader = saveReader(None)

        # SC_ERROR saveReaderCreateBottomToTop(
        #   saveReader* phReader,
        #   const char* pFileName)
        hsavec.saveReaderCreateBottomToTop(
            byref(hReader),
            file_name_p)

        return hReader.value
    
    # only call from __init__
    @staticmethod
    def _CreateBottomtoTopU(file_name):

        file_name_p = wchar_ptr(file_name)
        hReader = saveReader(None)

        # SC_ERROR saveReaderCreateBottomtoTopU(
        #   saveReader* phReader,
        #   const wchar_t* pFileName)
        hsavec.saveReaderCreateBottomtoTopU(
            byref(hReader),
            file_name_p)

        return hReader.value
    
    # only call from __del__
    def _Destroy(self):

        # SC_ERROR saveReaderDestroy(
        #   saveReader hReader)
        hsavec.saveReaderDestroy(
            self.hReader)

    def GetParams(self):

        width = size_t(0)
        height = size_t(0)
        bits_per_pixel = size_t(0)

        # SC_ERROR saveReaderGetParams(
        #   saveReader hReader,
        #   size_t * pWidth,
        #   size_t * pHeight,
        #   size_t * pBitsPerPixel)
        hsavec.saveReaderGetParams(
            self.hReader,
            byref(width),
            byref(height),
            byref(bits_per_pixel))

        return width.value, height.value, bits_per_pixel.value
    
    def GetData(self):

        pdata = POINTER(uint8_t)(uint8_t(0))

        # SC_ERROR saveReaderGetData(
        #   saveReader hReader,
        #   uint8_t** ppData)
        hsavec.saveReaderGetData(
            self.hReader,
            byref(pdata))

        return pdata

    @staticmethod
    def LoadRawData(file_name, size):

        array = (uint8_t * size)()
        pdata = cast(array, POINTER(uint8_t))
        file_name_p = char_ptr(file_name.encode())
        # SC_ERROR saveReaderLoadRawData(
        #   const char* pFileName, 
        #   uint8_t* pImageData, 
        #   const size_t size)
        hsavec.saveReaderLoadRawData(file_name_p, pdata, size)

        return pdata


    @staticmethod
    def LoadRawDataU(file_name, size):
        
        array = (uint8_t * size)()
        pdata = cast(array, POINTER(uint8_t))
        file_name_p = wchar_ptr(file_name)
        # SC_ERROR saveReaderLoadRawDataU(
        #   const wchar_t* pFileName, 
        #   uint8_t* pImageData, 
        #   const size_t size)
        hsavec.saveReaderLoadRawDataU(file_name_p, pdata, size)

        return pdata
